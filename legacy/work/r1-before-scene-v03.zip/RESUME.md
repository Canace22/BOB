# 当前迭代

v0.2 接续记录见 [RESUME-v02.md](RESUME-v02.md)。旧v0.1生产账本与代码已保存在 production-history/，旧运行包保留在 G:/鲸落万物生/builds/须门遗港-v0.1。

恢复时先运行 tools/ledger.cjs status 与 next，读取当前阶段，不依据本文直接认定验收完成。
