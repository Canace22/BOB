@tool
extends Node2D
## Independent decorative transforms. No collision nodes inherit this script.
@export var sway: float = 0.0
@export var speed: float = 0.7
@export var phase: float = 0.0
@export var drift: Vector2 = Vector2.ZERO
@export var parallax: Vector2 = Vector2.ONE
var origin: Vector2
var elapsed: float = 0.0
var level: Node2D

func _ready() -> void:
	origin=position
	if Engine.is_editor_hint(): set_process(false)

func bind(owner_level: Node2D) -> void:
	level=owner_level

func _process(delta: float) -> void:
	elapsed+=delta
	rotation=sin(elapsed*speed+phase)*sway
	if material is ShaderMaterial:
		material.set_shader_parameter("wind_time",elapsed)
	position=origin+Vector2(sin(elapsed*speed+phase)*drift.x,cos(elapsed*speed*0.7+phase)*drift.y)
	if is_instance_valid(level) and is_instance_valid(level.camera):
		position+=level.camera.get_screen_center_position()*(Vector2.ONE-parallax)

func get_effect_state() -> Dictionary:
	return {"layer":"far","seconds":elapsed,"scroll_scale":[parallax.x,parallax.y],"texture_loaded":true}
