extends Node

var data: Dictionary = {"version":1,"checkpoint":0,"boss":false,"dash":false,"fragment":false,"habitat":false,"complete":false}
var hp: int = 4
var energy: int = 4
var qa := false
var events: Array = []
var room_index := 0
var hits_on_boss := 0
var deaths := 0
var save_file: String:
	get: return "user://save-qa.json" if qa else "user://save-v1.json"

func record(event: String, detail: Dictionary = {}) -> void:
	events.append({"frame":Engine.get_physics_frames(),"event":event,"room":room_index,"detail":detail})
	print("EVENT ",event," ",JSON.stringify(detail))

func save_game() -> void:
	var file := FileAccess.open(save_file + ".tmp",FileAccess.WRITE)
	file.store_string(JSON.stringify(data))
	file.close()
	if FileAccess.file_exists(save_file):
		DirAccess.copy_absolute(save_file,save_file+".bak")
	DirAccess.rename_absolute(save_file+".tmp",save_file)

func load_game() -> void:
	if not FileAccess.file_exists(save_file): return
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(save_file))
	if parsed is Dictionary and parsed.get("version",0)==1:
		data.merge(parsed,true)

func reset_game() -> void:
	data={"version":1,"checkpoint":0,"boss":false,"dash":false,"fragment":false,"habitat":false,"complete":false}
	hp=4
	energy=4
	save_game()
	record("new_journey")
